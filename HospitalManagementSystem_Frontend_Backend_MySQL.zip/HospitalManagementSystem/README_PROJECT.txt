Hospital Management System
- Flutter frontend: lib/ and pubspec.yaml
- Existing Firebase backend: lib/backend/ (Firebase setup still required)
- MySQL PHP REST API and SQL database: mysql_backend/
Important: Flutter UI is currently wired to Firebase/Firestore, not MySQL.
See mysql_backend/README_MYSQL.txt before setup.
