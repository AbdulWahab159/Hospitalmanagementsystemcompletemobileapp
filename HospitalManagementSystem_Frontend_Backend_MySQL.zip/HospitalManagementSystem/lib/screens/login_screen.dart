import 'package:flutter/material.dart';
import '../backend/auth_service.dart';
import 'home_screen.dart';
import '../theme/app_theme.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  String role = 'Admin';
  bool obscure = true;
  bool loading = false;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> login() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter your email and password.')),
      );
      return;
    }
    setState(() => loading = true);
    try {
      await AuthService.instance.signIn(
        email: email.text,
        password: password.text,
        selectedRole: role,
      );
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => HomeScreen(role: role)),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> resetPassword() async {
    if (email.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter your email address first.')),
      );
      return;
    }
    try {
      await AuthService.instance.sendPasswordReset(email.text);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password reset email sent.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const SizedBox(height: 25),
                Container(
                  height: 88, width: 88,
                  decoration: BoxDecoration(color: AppTheme.navy, borderRadius: BorderRadius.circular(25)),
                  child: const Icon(Icons.local_hospital_rounded, color: Colors.white, size: 48),
                ),
                const SizedBox(height: 25),
                const Text('CarePoint Hospital', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: AppTheme.navy)),
                const SizedBox(height: 8),
                const Text('Hospital Management System', style: TextStyle(color: Colors.blueGrey)),
                const SizedBox(height: 32),
                const Text('Sign in', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                const SizedBox(height: 18),
                DropdownButtonFormField<String>(
                  value: role,
                  decoration: const InputDecoration(labelText: 'Login as', prefixIcon: Icon(Icons.person_outline)),
                  items: ['Admin', 'Doctor', 'Patient'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                  onChanged: loading ? null : (v) => setState(() => role = v ?? 'Admin'),
                ),
                const SizedBox(height: 14),
                TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email_outlined))),
                const SizedBox(height: 14),
                TextField(controller: password, obscureText: obscure, onSubmitted: (_) => login(), decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined), onPressed: () => setState(() => obscure = !obscure)))),
                Align(alignment: Alignment.centerRight, child: TextButton(onPressed: loading ? null : resetPassword, child: const Text('Forgot password?'))),
                const SizedBox(height: 10),
                FilledButton(
                  onPressed: loading ? null : login,
                  style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16), backgroundColor: AppTheme.navy),
                  child: loading
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Sign In'),
                ),
                const SizedBox(height: 12),
                const Text('Use an account created in your Firebase project.', textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
