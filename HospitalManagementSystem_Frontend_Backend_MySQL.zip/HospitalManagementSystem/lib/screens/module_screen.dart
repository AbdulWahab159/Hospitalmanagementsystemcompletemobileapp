import 'package:flutter/material.dart';
import '../backend/firestore_service.dart';
import '../data/module_data.dart';
import '../theme/app_theme.dart';

class ModuleScreen extends StatefulWidget {
  final HospitalModule module;
  const ModuleScreen({super.key, required this.module});
  @override
  State<ModuleScreen> createState() => _ModuleScreenState();
}

class _ModuleScreenState extends State<ModuleScreen> {
  final search = TextEditingController();
  bool saving = false;

  String get collection => _collectionName(widget.module.title);

  String _collectionName(String title) {
    const map = {
      'Patients': 'patients',
      'Doctors': 'doctors',
      'Appointments': 'appointments',
      'Medical Records': 'medical_records',
      'Prescriptions': 'prescriptions',
      'Pharmacy': 'pharmacy',
      'Laboratory': 'laboratory',
      'Billing & Payments': 'billing',
      'Staff': 'staff',
      'Departments': 'departments',
      'Beds': 'beds',
      'Wards': 'wards',
      'Emergency': 'emergency',
      'Ambulance': 'ambulances',
      'Notifications': 'notifications',
      'Reports & Analytics': 'reports',
      'Inventory': 'inventory',
      'Blood Bank': 'blood_bank',
      'Operation Theatre': 'operation_theatre',
      'Patient Discharge': 'discharges',
      'Attendance': 'attendance',
      'Payroll': 'payroll',
      'Feedback': 'feedback',
      'Settings': 'settings',
    };
    return map[title] ?? 'miscellaneous';
  }

  @override
  void dispose() { search.dispose(); super.dispose(); }

  Future<void> addRecord() async {
    final controllers = widget.module.fields.map((_) => TextEditingController()).toList();
    await showDialog(context: context, builder: (dialogContext) => AlertDialog(
      title: Text('Add ${widget.module.title} record'),
      content: SizedBox(width: 420, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: List.generate(widget.module.fields.length, (i) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(controller: controllers[i], decoration: InputDecoration(labelText: widget.module.fields[i])),
      ))))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
        FilledButton(onPressed: saving ? null : () async {
          final values = <String, dynamic>{};
          for (var i = 0; i < controllers.length; i++) {
            values[_fieldKey(widget.module.fields[i])] = controllers[i].text.trim();
          }
          values['displayName'] = controllers.map((c) => c.text.trim()).where((s) => s.isNotEmpty).join(' • ');
          if ((values['displayName'] as String).isEmpty) return;
          setState(() => saving = true);
          try {
            await FirestoreService.instance.addRecord(collection, values);
            if (dialogContext.mounted) Navigator.pop(dialogContext);
          } catch (e) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save: $e')));
          } finally {
            if (mounted) setState(() => saving = false);
          }
          for (final c in controllers) { c.dispose(); }
        }, child: const Text('Save')),
      ],
    ));
  }

  String _fieldKey(String label) => label
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
      .replaceAll(RegExp(r'^_|_$'), '');

  Future<void> _editRecord(Map<String, dynamic> record) async {
    final controller = TextEditingController(text: (record['displayName'] ?? '').toString());
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Edit record'),
      content: TextField(controller: controller, decoration: const InputDecoration(labelText: 'Record details')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () async {
          final value = controller.text.trim();
          if (value.isEmpty) return;
          try {
            await FirestoreService.instance.updateRecord(collection, record['id'], {'displayName': value});
            if (ctx.mounted) Navigator.pop(ctx);
          } catch (e) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Update failed: $e')));
          }
          controller.dispose();
        }, child: const Text('Update')),
      ],
    ));
  }

  Future<void> _deleteRecord(String id) async {
    final confirm = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Delete record?'),
      content: const Text('This record will be deleted from the database.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
      ],
    ));
    if (confirm != true) return;
    try {
      await FirestoreService.instance.deleteRecord(collection, id);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Delete failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.module.title)),
      floatingActionButton: FloatingActionButton.extended(onPressed: addRecord, icon: const Icon(Icons.add), label: const Text('Add New')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
          CircleAvatar(radius: 27, backgroundColor: const Color(0xFFE6F4F1), child: Icon(widget.module.icon, color: AppTheme.teal, size: 28)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.module.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 4),
            Text(widget.module.description, style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
          ])),
        ]))),
        const SizedBox(height: 16),
        TextField(controller: search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search records...')),
        const SizedBox(height: 14),
        StreamBuilder<List<Map<String, dynamic>>>(
          stream: FirestoreService.instance.watchRecords(collection),
          builder: (context, snapshot) {
            if (snapshot.hasError) return Padding(padding: const EdgeInsets.all(20), child: Text('Database error: ${snapshot.error}'));
            if (snapshot.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator()));
            final records = (snapshot.data ?? []).where((r) {
              final label = (r['displayName'] ?? r.values.join(' ')).toString();
              return label.toLowerCase().contains(search.text.toLowerCase());
            }).toList();
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [const Text('Records', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const Spacer(), Chip(label: Text('${records.length} items'))]),
              const SizedBox(height: 8),
              if (records.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No records found. Add a new record.'))),
              ...records.map((record) {
                final label = (record['displayName'] ?? 'Record').toString();
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(backgroundColor: const Color(0xFFEAF0FF), child: Icon(widget.module.icon, color: AppTheme.navy, size: 20)),
                    title: Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: const Text('Saved in Firebase Firestore'),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) {
                        if (v == 'Delete') _deleteRecord(record['id'].toString());
                        if (v == 'Edit') _editRecord(record);
                      },
                      itemBuilder: (_) => const [PopupMenuItem(value: 'Edit', child: Text('Edit')), PopupMenuItem(value: 'Delete', child: Text('Delete'))],
                    ),
                  ),
                );
              }),
            ]);
          },
        ),
        const SizedBox(height: 80),
      ]),
    );
  }
}
