import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  FirestoreService._();
  static final FirestoreService instance = FirestoreService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> _collection(String name) =>
      _db.collection(name);

  Stream<List<Map<String, dynamic>>> watchRecords(String collection) {
    return _collection(collection)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => {'id': doc.id, ...doc.data()})
            .toList());
  }

  Future<List<Map<String, dynamic>>> getRecords(String collection) async {
    final snapshot = await _collection(collection)
        .orderBy('createdAt', descending: true)
        .get();
    return snapshot.docs
        .map((doc) => {'id': doc.id, ...doc.data()})
        .toList();
  }

  Future<String> addRecord(
    String collection,
    Map<String, dynamic> data,
  ) async {
    final now = FieldValue.serverTimestamp();
    final doc = await _collection(collection).add({
      ...data,
      'createdAt': now,
      'updatedAt': now,
    });
    return doc.id;
  }

  Future<void> updateRecord(
    String collection,
    String id,
    Map<String, dynamic> data,
  ) async {
    await _collection(collection).doc(id).update({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteRecord(String collection, String id) =>
      _collection(collection).doc(id).delete();

  Future<Map<String, dynamic>?> getRecord(String collection, String id) async {
    final doc = await _collection(collection).doc(id).get();
    if (!doc.exists) return null;
    return {'id': doc.id, ...doc.data()!};
  }

  Future<int> count(String collection) async {
    final result = await _collection(collection).count().get();
    return result.count ?? 0;
  }

  Future<Map<String, int>> dashboardCounts() async {
    const collections = [
      'patients', 'doctors', 'appointments', 'beds',
    ];
    final results = await Future.wait(collections.map(count));
    return {
      for (var i = 0; i < collections.length; i++) collections[i]: results[i],
    };
  }
}
