import 'dart:convert';
import 'package:http/http.dart' as http;

/// MySQL REST API client. Use your computer's LAN IP on a physical phone.
class MySqlApiService {
  static const String baseUrl = 'http://10.0.2.2/hospital_api';
  static Future<List<dynamic>> getRecords(String module) async {
    final r = await http.get(Uri.parse('$baseUrl/records.php?module=$module'));
    if (r.statusCode != 200) throw Exception('Load failed: ${r.statusCode}');
    return jsonDecode(r.body) as List<dynamic>;
  }
  static Future<int> addRecord(String module, Map<String,dynamic> data) async {
    final r = await http.post(Uri.parse('$baseUrl/records.php?module=$module'), headers:{'Content-Type':'application/json'}, body:jsonEncode(data));
    if (r.statusCode != 201) throw Exception('Save failed: ${r.statusCode}');
    return (jsonDecode(r.body)['id'] as num).toInt();
  }
  static Future<void> updateRecord(String module,int id,Map<String,dynamic> data) async {
    final r=await http.put(Uri.parse('$baseUrl/records.php?module=$module&id=$id'),headers:{'Content-Type':'application/json'},body:jsonEncode(data));
    if(r.statusCode!=200) throw Exception('Update failed: ${r.statusCode}');
  }
  static Future<void> deleteRecord(String module,int id) async {
    final r=await http.delete(Uri.parse('$baseUrl/records.php?module=$module&id=$id'));
    if(r.statusCode!=200) throw Exception('Delete failed: ${r.statusCode}');
  }
}
