import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<Map<String, dynamic>> signIn({
    required String email,
    required String password,
    required String selectedRole,
  }) async {
    final credential = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = credential.user;
    if (user == null) throw Exception('Login failed. Please try again.');

    final doc = await _db.collection('users').doc(user.uid).get();
    if (!doc.exists) {
      await _auth.signOut();
      throw Exception('User profile not found. Contact the hospital administrator.');
    }

    final data = doc.data()!;
    final actualRole = (data['role'] ?? 'patient').toString().toLowerCase();
    if (actualRole != selectedRole.toLowerCase()) {
      await _auth.signOut();
      throw Exception('This account is registered as ${actualRole.toUpperCase()}, not $selectedRole.');
    }
    return data;
  }

  Future<UserCredential> registerPatient({
    required String name,
    required String email,
    required String password,
    required String phone,
  }) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = credential.user!;
    await _db.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'name': name.trim(),
      'email': email.trim(),
      'phone': phone.trim(),
      'role': 'patient',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'active': true,
    });
    return credential;
  }

  Future<void> sendPasswordReset(String email) =>
      _auth.sendPasswordResetEmail(email: email.trim());

  Future<void> signOut() => _auth.signOut();

  Future<Map<String, dynamic>?> getMyProfile() async {
    final user = currentUser;
    if (user == null) return null;
    final snap = await _db.collection('users').doc(user.uid).get();
    return snap.data();
  }

  Future<void> updateMyProfile({
    required String name,
    required String phone,
  }) async {
    final user = currentUser;
    if (user == null) throw Exception('Please sign in first.');
    await _db.collection('users').doc(user.uid).update({
      'name': name.trim(),
      'phone': phone.trim(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
