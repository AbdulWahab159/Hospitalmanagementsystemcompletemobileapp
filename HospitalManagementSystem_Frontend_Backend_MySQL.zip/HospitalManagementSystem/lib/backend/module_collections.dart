/// Firestore collection names used by the app.
/// Keep these names consistent with Firestore Security Rules.
class ModuleCollections {
  static const patients = 'patients';
  static const doctors = 'doctors';
  static const appointments = 'appointments';
  static const medicalRecords = 'medical_records';
  static const prescriptions = 'prescriptions';
  static const pharmacy = 'pharmacy';
  static const laboratory = 'laboratory';
  static const billing = 'billing';
  static const staff = 'staff';
  static const departments = 'departments';
  static const beds = 'beds';
  static const wards = 'wards';
  static const emergency = 'emergency';
  static const ambulances = 'ambulances';
  static const notifications = 'notifications';
  static const reports = 'reports';
  static const inventory = 'inventory';
  static const bloodBank = 'blood_bank';
  static const operationTheatre = 'operation_theatre';
  static const discharges = 'discharges';
  static const attendance = 'attendance';
  static const payroll = 'payroll';
  static const feedback = 'feedback';
  static const settings = 'settings';

  static const all = <String>[
    patients, doctors, appointments, medicalRecords, prescriptions,
    pharmacy, laboratory, billing, staff, departments, beds, wards,
    emergency, ambulances, notifications, reports, inventory, bloodBank,
    operationTheatre, discharges, attendance, payroll, feedback, settings,
  ];
}
