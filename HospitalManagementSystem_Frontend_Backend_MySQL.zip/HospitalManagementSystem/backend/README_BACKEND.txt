CAREPOINT HOSPITAL - FIREBASE BACKEND SETUP

1. Create a Firebase project at https://console.firebase.google.com/
2. In Firebase Console, add your Android app. Use the Android application ID from
   android/app/build.gradle(.kts) (the namespace/applicationId in your project).
3. Enable Authentication > Sign-in method > Email/Password.
4. Create a Cloud Firestore database.
5. Enable Firebase Storage if you need report/document uploads.
6. Install FlutterFire CLI:
      dart pub global activate flutterfire_cli
7. From the Flutter project root, run:
      flutterfire configure
   Select your Firebase project and Android platform. This generates
   lib/firebase_options.dart. Do not write this file by hand.
8. Replace Firestore Rules with ../firestore.rules in Firebase Console > Firestore
   Database > Rules. Replace Storage Rules with ../storage.rules in Storage > Rules.
9. Run:
      flutter pub get
      flutter run

AUTHENTICATION / ROLES
- Patient registration is available through AuthService.registerPatient().
- Admin and doctor accounts should be created by an administrator in Firebase
  Authentication, then a matching users/{uid} document must be created in Firestore.
- users/{uid} document example:
  { uid: "AUTH_UID", name: "Hospital Admin", email: "admin@example.com",
    phone: "03000000000", role: "admin", active: true }
- Allowed role strings: admin, doctor, patient (lowercase).
- Never allow a public client to choose its own admin/doctor role.

FIRESTORE COLLECTIONS
patients, doctors, appointments, medical_records, prescriptions, pharmacy,
laboratory, billing, staff, departments, beds, wards, emergency, ambulances,
notifications, reports, inventory, blood_bank, operation_theatre, discharges,
attendance, payroll, feedback, settings, users.

SERVICE FILES
lib/backend/auth_service.dart       Firebase email/password authentication
lib/backend/firestore_service.dart  Generic create/read/update/delete + counts
lib/backend/storage_service.dart    File upload/delete
lib/backend/module_collections.dart Collection name constants
lib/backend/validators.dart        Form validation helpers

IMPORTANT SECURITY NOTE
The included rules are a development starter, not a certified hospital system.
They allow all signed-in users to read operational collections and allow doctors
and admins to write. Before using real patient/medical data, add patient ownership
checks, least-privilege rules, audit logs, backups, and local legal/privacy review.
Never use real patient data in a classroom demo.
