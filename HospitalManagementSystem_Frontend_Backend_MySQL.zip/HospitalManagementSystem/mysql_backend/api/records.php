<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *'); // Restrict for production.
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD']==='OPTIONS') { http_response_code(204); exit; }
require __DIR__.'/db.php';
$allowed=['patients','doctors','appointments','medical_records','prescriptions','pharmacy','laboratory','billing','staff','departments','beds','wards','emergency','ambulances','notifications','reports','inventory','blood_bank','operation_theatres','discharges','attendance','payroll','feedback','settings'];
function out($data,$status=200){http_response_code($status);echo json_encode($data,JSON_UNESCAPED_UNICODE);exit;}
$module=strtolower($_GET['module']??''); if(!in_array($module,$allowed,true)) out(['error'=>'Invalid module'],400);
$method=$_SERVER['REQUEST_METHOD']; $id=(int)($_GET['id']??0); $body=json_decode(file_get_contents('php://input'),true);
try {
 if($method==='GET' && $id>0){$q=$pdo->prepare('SELECT id,module,payload,created_at,updated_at FROM module_records WHERE id=? AND module=?');$q->execute([$id,$module]);$r=$q->fetch();if(!$r)out(['error'=>'Record not found'],404);$r['payload']=json_decode($r['payload'],true);out($r);}
 if($method==='GET'){$q=$pdo->prepare('SELECT id,module,payload,created_at,updated_at FROM module_records WHERE module=? ORDER BY id DESC LIMIT 500');$q->execute([$module]);$rows=$q->fetchAll();foreach($rows as &$r)$r['payload']=json_decode($r['payload'],true);out($rows);}
 if($method==='POST'){if(!is_array($body))out(['error'=>'JSON object required'],400);$q=$pdo->prepare('INSERT INTO module_records(module,payload) VALUES(?,?)');$q->execute([$module,json_encode($body,JSON_UNESCAPED_UNICODE)]);out(['id'=>(int)$pdo->lastInsertId(),'message'=>'Created'],201);}
 if($method==='PUT'){if($id<1||!is_array($body))out(['error'=>'Valid id and JSON object required'],400);$q=$pdo->prepare('UPDATE module_records SET payload=? WHERE id=? AND module=?');$q->execute([json_encode($body,JSON_UNESCAPED_UNICODE),$id,$module]);if(!$q->rowCount())out(['message'=>'No changes or record not found'],404);out(['message'=>'Updated']);}
 if($method==='DELETE'){if($id<1)out(['error'=>'Valid id required'],400);$q=$pdo->prepare('DELETE FROM module_records WHERE id=? AND module=?');$q->execute([$id,$module]);if(!$q->rowCount())out(['error'=>'Record not found'],404);out(['message'=>'Deleted']);}
 out(['error'=>'Method not allowed'],405);
} catch(Throwable $e){out(['error'=>'Server error'],500);}
