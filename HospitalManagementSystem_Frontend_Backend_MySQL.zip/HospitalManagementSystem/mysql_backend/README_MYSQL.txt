MYSQL BACKEND SETUP (XAMPP)
1. Start Apache and MySQL in XAMPP.
2. Create htdocs/hospital_api and copy api/db.php and api/records.php into it.
3. Copy config/config.example.php to config/config.php and set MySQL credentials.
   Keep config.php private.
4. Import database/hospital_management.sql in phpMyAdmin.
5. Android emulator API URL: http://10.0.2.2/hospital_api
   Physical phone: replace 10.0.2.2 with your computer's LAN IP (same Wi-Fi).
6. Add dependency under dependencies in pubspec.yaml: http: ^1.2.2
7. Add INTERNET permission to AndroidManifest.xml. For local HTTP development
   configure cleartext traffic; use HTTPS in deployment.

IMPORTANT INTEGRATION NOTE
The existing Flutter screens currently use Firebase Auth / Cloud Firestore.
The MySQL PHP REST API and Dart API client are included separately, but the
screens have NOT yet been rewired from Firestore to MySQL. These databases do
not synchronize. To use MySQL end-to-end, replace Firestore calls in the UI
with MySqlApiService and implement secure authentication.

This is an academic/demo starter, not a production medical-record system.
Use fictional data only. The flexible JSON records table is not a normalized
clinical schema. Add authentication/authorization, patient ownership checks,
input validation, audit logs, backups, HTTPS and privacy safeguards before use.
Never connect Flutter directly to MySQL or put DB credentials in the app.
