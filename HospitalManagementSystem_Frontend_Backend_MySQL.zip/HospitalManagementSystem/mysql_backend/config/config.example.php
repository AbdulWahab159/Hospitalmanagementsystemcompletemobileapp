<?php
// Copy to config.php and set local credentials. Never publish real passwords.
return ['host'=>'127.0.0.1','database'=>'hospital_management','username'=>'root','password'=>'','charset'=>'utf8mb4'];
