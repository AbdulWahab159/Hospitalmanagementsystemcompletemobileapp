DATABASE SETUP - FIRESTORE

1. Open Firebase Console and select your project.
2. Open Build > Firestore Database > Create database.
3. Start in production mode (not test mode).
4. Choose a region close to your expected users; region choice is difficult to change later.
5. Open Rules and deploy the project's firestore.rules after reviewing and tightening them.
6. Create the first users/{AUTH_UID} document for the administrator:
   - First create the account in Firebase Authentication.
   - Copy that account's UID.
   - Create a Firestore users document whose document ID is exactly that UID.
   - Set role to admin. Do this only from the Firebase Console/trusted admin process.
7. Collections are created automatically when the app adds the first document.
8. See Firestore_Database_Schema.md for every collection, field, status and relationship.
9. See seed_templates.json for example document shapes. Replace all demo IDs and values.

IMPORTANT:
- Firestore is NoSQL. There is no SQL CREATE TABLE script.
- This schema is not automatically imported by uploading the JSON template.
- Use only fictional sample data for your class project.
- Never expose Firebase service-account private keys in Flutter/mobile code.
- Review access rules carefully before storing real medical or personal data.
