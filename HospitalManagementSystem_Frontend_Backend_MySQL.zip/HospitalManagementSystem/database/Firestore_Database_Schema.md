# CarePoint Hospital Management System — Firestore Database Schema

This is a development/demo schema for the Flutter project. Use synthetic data only.
Firestore is a NoSQL document database: create collections/documents as records are added.
Do not create all collections manually; the first document creates a collection.

## Common conventions
- Document ID: Firestore-generated ID unless noted otherwise.
- createdAt, updatedAt: Firestore Timestamp.
- createdBy: Firebase Auth UID of staff member who created the record.
- status: use the suggested values below consistently.
- References: store related document IDs in fields ending in `Id`.
- Keep personal/medical data to a minimum in a classroom demo.

## Authentication and users
Collection: `users/{uid}` (document ID MUST equal Firebase Authentication UID)
Fields:
- uid: string
- name: string
- email: string
- phone: string
- role: `admin` | `doctor` | `patient`
- active: boolean
- createdAt: timestamp
- updatedAt: timestamp
Optional:
- doctorId: string (for a linked doctor profile)
- patientId: string (for a linked patient profile)

Patient self-registration may create only role=patient. Admin/doctor accounts must be provisioned by a trusted admin process, not by public signup.

## Collections and fields

### patients
- patientCode: string (unique human-readable code, e.g. PAT-0001)
- fullName: string
- dateOfBirth: timestamp
- gender: string
- phone: string
- email: string
- address: string
- bloodGroup: string
- emergencyContactName: string
- emergencyContactPhone: string
- assignedDoctorId: string
- status: `active` | `inactive`
- createdAt, updatedAt: timestamp
- createdBy: string (UID)

### doctors
- doctorCode: string
- fullName: string
- email: string
- phone: string
- specialty: string
- departmentId: string
- qualification: string
- consultationFee: number
- availability: array of strings
- status: `active` | `on_leave` | `inactive`
- createdAt, updatedAt: timestamp
- createdBy: string

### appointments
- patientId: string
- patientName: string (display snapshot)
- doctorId: string
- doctorName: string (display snapshot)
- appointmentDate: timestamp
- reason: string
- status: `pending` | `confirmed` | `completed` | `cancelled`
- createdAt, updatedAt: timestamp
- createdBy: string

### medical_records
- patientId: string
- doctorId: string
- appointmentId: string (optional)
- diagnosis: string
- notes: string
- visitDate: timestamp
- attachments: array of download URL strings (optional)
- createdAt, updatedAt: timestamp
- createdBy: string

### prescriptions
- patientId: string
- doctorId: string
- medicalRecordId: string (optional)
- medicines: array of maps: {medicineName, dosage, frequency, duration, instructions}
- prescribedAt: timestamp
- notes: string
- status: `active` | `completed` | `cancelled`
- createdAt, updatedAt: timestamp
- createdBy: string

### pharmacy
- medicineName: string
- genericName: string
- category: string
- quantity: number
- unit: string
- unitPrice: number
- expiryDate: timestamp
- reorderLevel: number
- status: `available` | `low_stock` | `out_of_stock`
- createdAt, updatedAt: timestamp
- createdBy: string

### laboratory
- patientId: string
- patientName: string
- testName: string
- requestedByDoctorId: string
- requestedAt: timestamp
- resultSummary: string
- reportUrl: string (optional)
- status: `requested` | `in_progress` | `completed` | `cancelled`
- createdAt, updatedAt: timestamp
- createdBy: string

### billing
- invoiceNumber: string
- patientId: string
- patientName: string
- appointmentId: string (optional)
- lineItems: array of maps: {description, quantity, unitPrice, total}
- subtotal: number
- discount: number
- totalAmount: number
- paymentMethod: `cash` | `card` | `bank_transfer` | `other`
- paymentStatus: `unpaid` | `partially_paid` | `paid` | `refunded`
- issuedAt: timestamp
- createdAt, updatedAt: timestamp
- createdBy: string

### staff
- fullName: string
- roleTitle: string
- departmentId: string
- phone: string
- email: string
- employmentStatus: `active` | `on_leave` | `inactive`
- createdAt, updatedAt: timestamp
- createdBy: string

### departments
- name: string
- description: string
- headDoctorId: string
- location: string
- status: `active` | `inactive`
- createdAt, updatedAt: timestamp
- createdBy: string

### beds
- bedNumber: string
- wardId: string
- bedType: string
- patientId: string (empty when unoccupied)
- status: `available` | `occupied` | `maintenance`
- createdAt, updatedAt: timestamp
- createdBy: string

### wards
- name: string
- floor: string
- capacity: number
- status: `open` | `closed`
- createdAt, updatedAt: timestamp
- createdBy: string

### emergency
- patientId: string (optional for unidentified patient)
- patientName: string
- arrivalAt: timestamp
- triageLevel: `critical` | `urgent` | `standard`
- assignedDoctorId: string
- notes: string
- status: `arrived` | `under_care` | `admitted` | `discharged`
- createdAt, updatedAt: timestamp
- createdBy: string

### ambulances
- vehicleCode: string
- driverName: string
- driverPhone: string
- vehicleNumber: string
- status: `available` | `on_duty` | `maintenance`
- currentAssignmentId: string (optional)
- createdAt, updatedAt: timestamp
- createdBy: string

### notifications
- recipientUid: string
- title: string
- message: string
- type: string
- read: boolean
- createdAt: timestamp

### reports
- title: string
- reportType: string
- periodStart: timestamp
- periodEnd: timestamp
- fileUrl: string (optional)
- generatedBy: string
- createdAt: timestamp

### inventory
- itemName: string
- category: string
- quantity: number
- unit: string
- reorderLevel: number
- supplier: string
- status: `in_stock` | `low_stock` | `out_of_stock`
- createdAt, updatedAt: timestamp
- createdBy: string

### blood_bank
- bloodGroup: string
- unitsAvailable: number
- lastUpdated: timestamp
- status: `available` | `low_stock` | `unavailable`
- createdAt, updatedAt: timestamp
- createdBy: string

### operation_theatre
- theatreCode: string
- procedureName: string
- patientId: string
- surgeonId: string
- scheduledStart: timestamp
- scheduledEnd: timestamp
- status: `scheduled` | `in_progress` | `completed` | `cancelled`
- createdAt, updatedAt: timestamp
- createdBy: string

### discharges
- patientId: string
- admissionDate: timestamp
- dischargeDate: timestamp
- summary: string
- followUpInstructions: string
- status: `draft` | `reviewed` | `completed`
- createdAt, updatedAt: timestamp
- createdBy: string

### attendance
- employeeUid: string
- employeeName: string
- date: timestamp
- checkIn: timestamp
- checkOut: timestamp (optional)
- status: `present` | `absent` | `late` | `leave`
- createdAt, updatedAt: timestamp
- createdBy: string

### payroll
- employeeUid: string
- employeeName: string
- payPeriod: string (e.g. 2026-11)
- basicSalary: number
- allowances: number
- deductions: number
- netSalary: number
- paymentStatus: `pending` | `paid`
- paidAt: timestamp (optional)
- createdAt, updatedAt: timestamp
- createdBy: string

### feedback
- patientId: string
- patientName: string
- rating: number (1 to 5)
- comment: string
- createdAt: timestamp

### settings
- hospitalName: string
- address: string
- phone: string
- email: string
- currency: string
- updatedAt: timestamp
- updatedBy: string

## Relationships (store IDs, not nested duplicate records)
- patients.assignedDoctorId -> doctors/{doctorId}
- doctors.departmentId -> departments/{departmentId}
- appointments.patientId -> patients/{patientId}
- appointments.doctorId -> doctors/{doctorId}
- medical_records.patientId -> patients/{patientId}
- medical_records.doctorId -> doctors/{doctorId}
- prescriptions.patientId -> patients/{patientId}
- prescriptions.doctorId -> doctors/{doctorId}
- laboratory.patientId -> patients/{patientId}
- billing.patientId -> patients/{patientId}
- beds.wardId -> wards/{wardId}
- beds.patientId -> patients/{patientId}
- operation_theatre.patientId -> patients/{patientId}
- operation_theatre.surgeonId -> doctors/{doctorId}

## Suggested Firestore composite indexes
Create these only if Firestore reports a missing-index link:
- appointments: doctorId ASC, appointmentDate ASC
- appointments: patientId ASC, appointmentDate DESC
- medical_records: patientId ASC, visitDate DESC
- prescriptions: patientId ASC, prescribedAt DESC
- laboratory: patientId ASC, requestedAt DESC
- billing: patientId ASC, issuedAt DESC
- notifications: recipientUid ASC, createdAt DESC
- attendance: employeeUid ASC, date DESC

## Important
This schema is an academic/demo starting point, not a certified clinical records platform.
The sample starter rules are not sufficient for real patient information. Enforce patient
ownership and staff role permissions, validate fields and file types, use audit logs,
backups, and obtain appropriate privacy/security review before any real deployment.
